import 'package:flutter/material.dart';
import 'package:CatatDong/tambah_data.dart';
import 'package:CatatDong/transaksi.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Catat Dong',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final List<Transaction> transactions = [
    Transaction(id: '1', title: 'Ayam Geprek', inex: 'Expenses', category: 'Food', price: 10000, date: DateTime.now()),
    Transaction(id: '2', title: 'Kuota', inex: 'Expenses', category: 'Entertainment', price: 20000, date: DateTime.now()),
    Transaction(id: '3', title: 'Mie Goreng', inex: 'Expenses', category: 'Food', price: 30000, date: DateTime.now()),
    Transaction(id: '4', title: 'Bansos', inex: 'Income', category: 'Gaji', price: 500000, date: DateTime.now()),
    Transaction(id: '5', inex: 'Expenses', category: 'Food', price: 5000, date: DateTime.now()),
  ];
  final List<Transaction> income = [];
  final List<Transaction> expenses = [];

  totalIncome() {
    double totInc = 0.0;
    income.forEach((e) {
      totInc += e.price.toDouble();
    });
    return totInc;
  }

  totalExpenses() {
    double totExp = 0.0;
    expenses.forEach((e) {
      totExp += e.price.toDouble();
    });
    return totExp;
  }

  totalBalance() {
    double totBnc = totalIncome() - totalExpenses();
    return totBnc;
  }

  @override
  void initState() {
    super.initState();
    transactions.forEach((e) {
      if (e.inex == 'Income') {
        income.add(e);
      } else if (e.inex == 'Expenses') {
        expenses.add(e);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Catat Dong',
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.yellow,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => AddData()),);
          },
          backgroundColor: Colors.yellow,
          child: Icon(FontAwesomeIcons.plus),
        ),
        body: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.yellow,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(color: Colors.black),
                    ),
                    padding: EdgeInsets.all(12.0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(FontAwesomeIcons.signInAlt, size: 14),
                            Text(" INCOME", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14.0),),
                          ],
                        ),
                        Text("Rp. ${totalIncome().toInt()}", style: TextStyle(fontSize: 14.0))
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.yellow,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(color: Colors.black),
                    ),
                    padding: EdgeInsets.all(12.0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(FontAwesomeIcons.signOutAlt, size: 14),
                            Text(" EXPENSES", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14.0),
                            ),
                          ],
                        ),
                        Text("Rp. ${totalExpenses().toInt()}", style: TextStyle(fontSize: 14.0))
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(color: Colors.black),
                    ),
                    padding: EdgeInsets.all(12.0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(FontAwesomeIcons.wallet, size: 14,),
                            Text(" BALANCE", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14.0)),
                          ],
                        ),
                        Text("Rp. ${totalBalance().toInt()}", style: TextStyle(fontSize: 14.0))
                      ],
                    ),
                  ),
                ],
              ),
              Container(
                margin: EdgeInsets.only(top: 20, bottom: 10),
                padding: const EdgeInsets.only(left: 8.0),
                child: Row(
                  children: [
                    Icon(FontAwesomeIcons.history, size: 16,),
                    Text(" History", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16.0),),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 20),
                padding: EdgeInsets.all(3.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  border: Border.all(color: Colors.black),
                ),
                child: TabBar(
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.yellow
                  ),
                  labelPadding: EdgeInsets.all(1),
                  tabs: [
                    Tab(child: Text("ALL", style: TextStyle(color: Colors.black))),
                    Tab(child: Text("INCOME", style: TextStyle(color: Colors.black)),),
                    Tab(child: Text("EXPENSES", style: TextStyle(color: Colors.black)),),
                  ]
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    ListView(
                      children: transactions.reversed.map((tx) {
                        return Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.black,width: 2,),
                          ),
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: width,
                                decoration: BoxDecoration(
                                  border: Border(bottom: BorderSide(color: Colors.black))
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(DateFormat('dd/MM/yyyy').format(tx.date)),
                                    tx.inex == 'Expenses' ? Text("Total : -${tx.price.toInt().toString()}") : Text("Total : ${tx.price.toInt().toString()}"),
                                    
                                  ],
                                ),
                              ),
                              Container(
                                width: width,
                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    children: [
                                      Container(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Icon(FontAwesomeIcons.signInAlt, size: 18,),
                                                tx.title == null ? Text(' ${tx.category}', style: TextStyle(fontSize: 16.0),) : Text(' ${tx.title}', style: TextStyle(fontSize: 16.0),),
                                              ],
                                            ),
                                            tx.inex == 'Expenses' ? Text("-${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),) : Text("${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        );
                      }).toList(),
                    ),

                    ListView(
                      children: income.reversed.map((tx) {
                        return Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.black,width: 2,),
                          ),
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: width,
                                decoration: BoxDecoration(
                                  border: Border(bottom: BorderSide(color: Colors.black))
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(DateFormat('dd/MM/yyyy').format(tx.date)),
                                    tx.inex == 'Expenses' ? Text("Total : -${tx.price.toInt().toString()}") : Text("Total : ${tx.price.toInt().toString()}"),
                                    
                                  ],
                                ),
                              ),
                              Container(
                                width: width,
                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    children: [
                                      Container(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Icon(FontAwesomeIcons.signInAlt, size: 18,),
                                                tx.title == null ? Text(' ${tx.category}', style: TextStyle(fontSize: 16.0),) : Text(' ${tx.title}', style: TextStyle(fontSize: 16.0),),
                                              ],
                                            ),
                                            tx.inex == 'Expenses' ? Text("-${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),) : Text("${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        );
                      }).toList(),
                    ),

                    ListView(
                      children: expenses.reversed.map((tx) {
                        return Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.black,width: 2,),
                          ),
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: width,
                                decoration: BoxDecoration(
                                  border: Border(bottom: BorderSide(color: Colors.black))
                                ),
                                padding: EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(DateFormat('dd/MM/yyyy').format(tx.date)),
                                    tx.inex == 'Expenses' ? Text("Total : -${tx.price.toInt().toString()}") : Text("Total : ${tx.price.toInt().toString()}"),
                                    
                                  ],
                                ),
                              ),
                              Container(
                                width: width,
                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    children: [
                                      Container(
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Icon(FontAwesomeIcons.signInAlt, size: 18,),
                                                tx.title == null ? Text(' ${tx.category}', style: TextStyle(fontSize: 16.0),) : Text(' ${tx.title}', style: TextStyle(fontSize: 16.0),),
                                              ],
                                            ),
                                            tx.inex == 'Expenses' ? Text("-${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),) : Text("${tx.price.toInt().toString()}", style: TextStyle(fontSize: 16.0),),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}