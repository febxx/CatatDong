import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AddData extends StatelessWidget {

  Widget buildButton(String btnText) {
    return FlatButton(
      padding: EdgeInsets.all(15),
      shape: RoundedRectangleBorder(side: BorderSide(color: Colors.grey)),
      onPressed: () {},
      child: Text(btnText, style: TextStyle(fontSize: 22, color: Colors.black),),
    );
  }

  Widget buildIcon(Icon btnIcon, Color btnColor) {
    return FlatButton(
      color: btnColor,
      padding: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(side: BorderSide(color: Colors.grey)),
      onPressed: () {},
      child: btnIcon,
    );
  }

  Widget buildCategory(String catText, Icon catIcon) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.yellow,
              borderRadius: BorderRadius.all(Radius.circular(30))
            ),
            child: catIcon,
          ),
          Text(catText)
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Add Data', style: TextStyle(color: Colors.black),),
          backgroundColor: Colors.yellow,
          leading: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            }, 
            child: Icon(FontAwesomeIcons.arrowLeft, color: Colors.black, size: 18,)
          ),
        ),
        body: Container(
          // padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(bottom: 20),
                padding: EdgeInsets.all(10.0),
                child: TabBar(
                  indicatorColor: Colors.yellow,
                  tabs: [
                    Tab(child: Text("INCOME", style: TextStyle(color: Colors.black))),
                    Tab(child: Text("EXPENSES", style: TextStyle(color: Colors.black))),
                  ],
                ),
              ),
              Container(
                child: Expanded(
                  child: TabBarView(
                    children: [
                      GridView.count(
                        crossAxisCount: 4,
                        children: [
                          buildCategory('Food', Icon(FontAwesomeIcons.utensils)),
                          buildCategory('Game', Icon(Icons.gamepad)),
                          buildCategory('Shopping', Icon(FontAwesomeIcons.shoppingBag)),
                          buildCategory('Home', Icon(FontAwesomeIcons.home)),
                          buildCategory('Health', Icon(FontAwesomeIcons.briefcaseMedical)),
                          buildCategory('Telephone', Icon(FontAwesomeIcons.phone)),
                          buildCategory('Education', Icon(Icons.school)),
                          buildCategory('Office', Icon(FontAwesomeIcons.building)),
                        ]
                      ),
                      GridView.count(
                        crossAxisCount: 4,
                        children: [
                          buildCategory('Salary', Icon(FontAwesomeIcons.wallet)),
                          buildCategory('Invesment', Icon(FontAwesomeIcons.piggyBank)),
                          buildCategory('Lottery', Icon(FontAwesomeIcons.dice)),
                          buildCategory('Others', Icon(FontAwesomeIcons.random)),
                        ]
                      )
                    ],
                  )
                ),
              ),
              Row(
                children: <Widget>[
                  Container(
                    child: Row(

                    ),
                  ),
                  Container(
                    width: width,
                    child: Table(
                      children: [
                        TableRow(
                          children: [
                            buildButton('7'),
                            buildButton('8'),
                            buildButton('9'),
                            buildButton('Today'),
                          ]
                        ),
                        TableRow(
                          children: [
                            buildButton('4'),
                            buildButton('5'),
                            buildButton('6'),
                            buildButton('+'),
                          ]
                        ),
                        TableRow(
                          children: [
                            buildButton('1'),
                            buildButton('2'),
                            buildButton('3'),
                            buildButton('-'),
                          ]
                        ),
                        TableRow(
                          children: [
                            buildButton('.'),
                            buildButton('0'),
                            buildIcon(Icon(FontAwesomeIcons.backspace), Colors.white),
                            buildIcon(Icon(FontAwesomeIcons.checkCircle), Colors.yellow),
                          ]
                        ),
                      ]
                    ),
                  )
                ],
              )
            ]
          ),
        ),
      ),
    );
  }
}