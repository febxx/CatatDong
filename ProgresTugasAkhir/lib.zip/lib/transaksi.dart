class Transaction {
   final String id;
   final String title;
   final String inex;
   final String category;
   final double price;
   final DateTime date;

   Transaction({
     this.id, this.title, this.inex, this.category, this.price, this.date,
   });
}