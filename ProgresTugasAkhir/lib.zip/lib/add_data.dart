import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AddData extends StatefulWidget {

  @override
  _AddDataState createState() => _AddDataState();
}

class _AddDataState extends State<AddData> {
  
  Widget _buildCategory(String category) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50.0),
              border: Border.all(color: Colors.black),
            ),
          ),
          Text('$category')
        ]
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Add Data', style: TextStyle(color: Colors.black),),
          backgroundColor: Colors.yellow,
          leading: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            }, 
            child: Icon(FontAwesomeIcons.arrowLeft, color: Colors.black,)
          ),
        ),
        body: Container(
          padding: EdgeInsets.all(10),
          
          child: Column(
            children: <Widget>[
              Container(
                child: TabBar(
                  indicatorColor: Colors.yellow,
                  tabs: [
                    Tab(child: Text("INCOME", style: TextStyle(color: Colors.black))),
                    Tab(child: Text("EXPENSES", style: TextStyle(color: Colors.black))),
                  ],
                ),
              ),
              Container(
                child: TabBarView(
                  children: [
                    GridView.count(
                      crossAxisCount: 5,
                      children: List.generate(10, (index) {
                        return Center(
                          child: Text('Item $index'),
                        );
                      }),
                    ),
                    Text('asda')
                    // Divider(color: Colors.black, height: 2,),
                    // Divider(color: Colors.black, height: 2,),
                  ]
                ),
              )
              // TabBarView(
              //   children: [
              //     Divider(height: 1, color: Colors.black,),
              //     Divider(height: 1, color: Colors.black,)
              //   ],
              // ),
              // Expanded(
              //   child: GridView.count(
              //     crossAxisCount: 5,
              //     children: List.generate(10, (index) {
              //         return Center(
              //           child: Text(
              //             'Item $index',
              //             style: Theme.of(context).textTheme.headline5,
              //           ),
              //         );
              //       }
              //     ),
              //   )
              // ),

            ],
          ),
        ),
      ),
    );
  }
}